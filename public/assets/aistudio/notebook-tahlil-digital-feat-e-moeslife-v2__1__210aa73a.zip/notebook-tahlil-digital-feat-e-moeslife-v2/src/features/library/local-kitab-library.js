import { disclaimerMarkup } from '../../components/shell/footer.js';
let apiBooks = [];
const normalizeBookName = value => String(value || '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('id').replace(/[^a-z0-9]+/g, ' ').trim();
const BOOKS = [
  { file: 'safinah-an-najah.json', slug: 'safinah-an-najah', title: 'Safinah An-Najah', category: 'Fiqih' },
  { file: 'safinah-reading-library.json', slug: 'safinah-reading-library', title: 'Safinah An-Najah — Edisi Baru', category: 'Fiqih', format: 'structured' },
  { file: 'aqidatul-awam.json', slug: 'aqidatul-awam', title: 'Aqidatul Awam', category: 'Aqidah' },
  { file: 'arbain.json', slug: 'arbain', title: 'Arba’in Nawawi', category: 'Hadis' },
  { file: 'bidayatul.json', slug: 'bidayatul', title: 'Bidayatul Hidayah', category: 'Tasawuf' },
  { file: 'bulughul.json', slug: 'bulughul', title: 'Bulughul Maram', category: 'Hadis' },
  { file: 'futuhul.json', slug: 'futuhul', title: 'Futuhul Ghaib', category: 'Tasawuf' },
  { file: 'izar.json', slug: 'izar', title: 'Fathul Izar', category: 'Fikih & Adab' },
  { file: 'jalalain.json', slug: 'jalalain', title: 'Tafsir Jalalain', category: 'Tafsir' },
  { file: 'muslim.json', slug: 'muslim', title: 'Shahih Muslim', category: 'Hadis' },
  { file: 'muwatta.json', slug: 'muwatta', title: 'Muwatta Imam Malik', category: 'Hadis' },
  { file: 'qarib.json', slug: 'qarib', title: 'Fathul Qarib', category: 'Fiqih' },
  { file: 'taklim.json', slug: 'taklim', title: 'Ta’lim Al-Muta’allim', category: 'Adab' },
  { file: 'uyun.json', slug: 'uyun', title: 'Qurrotul Uyun', category: 'Keluarga' },
  { file: 'alhikam.json', slug: 'alhikam', title: 'Al-Hikam', category: 'Tasawuf' }
];
const CHUNK_TARGET_CHARS = 4000;
const BATCH_BUDGET_CHARS = 8000;
/**
 * Pecah teks panjang menjadi potongan pada batas paragraf (baris kosong) tanpa mengubah isi.
 * Menggabungkan kembali seluruh potongan selalu menghasilkan teks asli persis (harakat, tanda baca, baris baru).
 * Satu paragraf yang lebih panjang dari target tetap utuh; bila sangat panjang, dipecah pada akhir baris.
 */
export function chunkText(text, target = CHUNK_TARGET_CHARS) {
  const source = String(text || '');
  if (!source) return [];
  if (source.length <= target) return [source];
  const parts = source.split(/(\n{2,})/);
  const chunks = [];
  let current = '';
  for (let i = 0; i < parts.length; i += 2) {
    const unit = parts[i] + (parts[i + 1] || '');
    if (current && current.length + unit.length > target) { chunks.push(current); current = ''; }
    current += unit;
  }
  if (current) chunks.push(current);
  return chunks.flatMap(chunk => {
    if (chunk.length <= target * 3) return [chunk];
    const lines = chunk.split(/(?<=\n)/);
    const pieces = [];
    let piece = '';
    for (const line of lines) {
      if (piece && piece.length + line.length > target) { pieces.push(piece); piece = ''; }
      piece += line;
    }
    if (piece) pieces.push(piece);
    return pieces;
  });
}
/** Susun antrean render satu bab: Arab, Latin, lalu terjemahan, dengan urutan asli. */
export const splitParagraphs = text => String(text || '').split(/\n{2,}/).filter(paragraph => paragraph.trim());
const leadingNumber = paragraph => { const match = paragraph.match(/^\s*(\d+)[.)]\s/); return match ? Number(match[1]) : null; };
/**
 * Pasangkan paragraf Arab dan terjemah HANYA bila keselarasannya dapat diverifikasi dari penomoran terjemah
 * (misalnya nomor ayat pada Tafsir Jalalain). Jumlah paragraf yang sama saja tidak cukup untuk memasangkan.
 *  - Pola A: setiap terjemah bernomor 1, 2, 3, ... sejajar dengan paragraf Arab ke-1, 2, 3, ...
 *  - Pola B: paragraf pertama terjemah adalah judul tanpa nomor (misalnya "Shad Ayat 1-88"), sisanya bernomor sesuai urutan.
 *    Judul itu bukan terjemah paragraf Arab pertama (basmalah), jadi ditandai heading dan tidak dilipat.
 * Selain itu, atau bila bab memiliki Latin, kembalikan null. Isi paragraf tidak diubah.
 */
export function pairParagraphs(chapter) {
  if (chapter.latin) return null;
  const arabic = splitParagraphs(chapter.arabic);
  const translation = splitParagraphs(chapter.translation);
  if (arabic.length < 2 || arabic.length !== translation.length) return null;
  const direct = translation.every((paragraph, index) => leadingNumber(paragraph) === index + 1);
  const withHeading = leadingNumber(translation[0]) === null && translation.slice(1).every((paragraph, index) => leadingNumber(paragraph) === index + 1);
  if (!direct && !withHeading) return null;
  return arabic.map((paragraph, index) => ({ arabic: paragraph, translation: translation[index], heading: withHeading && index === 0 }));
}
const UNPAIRED_VIEWS = ['both', 'arabic', 'translation'];
/** Tentukan mode tampilan bab dan pilihan yang ditawarkan, berdasarkan preferensi tersimpan. */
export function resolveView(chapter, prefs = {}) {
  if (pairParagraphs(chapter)) return { options: ['fold', 'classic'], view: prefs.paired === 'classic' ? 'classic' : 'fold' };
  if (chapter.arabic && chapter.translation) return { options: UNPAIRED_VIEWS, view: UNPAIRED_VIEWS.includes(prefs.unpaired) ? prefs.unpaired : 'both' };
  return { options: [], view: 'both' };
}
/** Susun antrean render satu bab. view: 'fold' (berpasangan, terjemah dilipat), 'both', 'arabic', 'translation'. */
export function buildChapterQueue(chapter, view = 'both') {
  const pairs = view === 'fold' ? pairParagraphs(chapter) : null;
  if (pairs) {
    return pairs.map((pair, index) => ({ kind: 'pair', heading: pair.heading, arabic: pair.arabic, translation: pair.translation, size: pair.arabic.length + 120, first: index === 0, last: index === pairs.length - 1 }));
  }
  const queue = [];
  [['arabic', chapter.arabic], ['latin', chapter.latin], ['translation', chapter.translation]]
    .filter(([kind]) => view === 'arabic' ? kind !== 'translation' : view === 'translation' ? kind === 'translation' : true)
    .forEach(([kind, text]) => {
      const chunks = chunkText(text);
      chunks.forEach((chunk, index) => queue.push({ kind, chunk, first: index === 0, last: index === chunks.length - 1 }));
    });
  return queue;
}
/** Jumlah item antrean yang dirender dalam satu gelombang (minimal satu). */
export function planBatch(queue, budget = BATCH_BUDGET_CHARS) {
  let count = 0;
  let used = 0;
  const sizeOf = item => item.size ?? item.chunk.length;
  while (count < queue.length && (count === 0 || used + sizeOf(queue[count]) <= budget)) {
    used += sizeOf(queue[count]);
    count += 1;
  }
  return count;
}
const VIEW_PREF_KEY = 'e-moeslife:kitab-view:v1';
const readViewPrefs = () => { try { return JSON.parse(localStorage.getItem(VIEW_PREF_KEY) || '{}') || {}; } catch { return {}; } };
const writeViewPref = (name, value) => { try { localStorage.setItem(VIEW_PREF_KEY, JSON.stringify({ ...readViewPrefs(), [name]: value })); } catch { /* penyimpanan tidak tersedia */ } };
const VIEW_LABELS = { fold: 'Lipat terjemah', classic: 'Seperti semula', both: 'Keduanya', arabic: 'Arab saja', translation: 'Terjemah saja' };
const manualKey = slug => 'e-moeslife:kitab-manual:v1:' + String(slug || 'kitab-lain').replace(/[^a-z0-9_-]/gi, '-');
/**
 * Salinan lokal hasil editor hanya dipakai bila lebih baru daripada file naskah di data/.
 * Bila naskah di server sudah diperbarui (updatedAt sama atau lebih baru), salinan lokal yang usang diabaikan.
 * Jika salah satu tanggal tidak dapat dibaca, salinan lokal tetap dipakai (perilaku lama).
 */
export function shouldUseLocalCopy(saved, source) {
  if (!(saved?.version === 1 && Array.isArray(saved.chapters) && saved.chapters.length)) return false;
  const savedAt = Date.parse(saved.updatedAt);
  const sourceAt = Date.parse(source?.updatedAt);
  if (!Number.isFinite(savedAt) || !Number.isFinite(sourceAt)) return true;
  return savedAt > sourceAt;
}
// Arsipkan, bukan hapus, agar hasil edit tidak hilang. Satu cadangan per kitab.
function archiveLocalCopy(slug) {
  const key = manualKey(slug);
  try {
    const raw = localStorage.getItem(key);
    if (raw === null) return true;
    localStorage.setItem(key + ':backup', raw);
    localStorage.removeItem(key);
    return true;
  } catch { return false; }
}
const ARABIC = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]/;
const ARABIC_KEYS = ['arabic', 'arab', 'teks_arab', 'teksArab', 'teks_arabic', 'arabic_text', 'arabicText', 'arab_text', 'isi_arab', 'naskah_arab', 'matan', 'text_ar'];
const LATIN_KEYS = ['latin', 'teks_latin', 'transliterasi'];
const TRANSLATION_KEYS = ['translation', 'terjemahan', 'teks_indonesia', 'teksIndonesia', 'indonesia', 'terjemah', 'arti', 'makna', 'content', 'isi', 'konten', 'text_id'];
const TITLE_KEYS = ['title', 'judul', 'nama_bab', 'judul_bab', 'nama', 'name', 'bab', 'chapter'];
const arrayAt = value => {
  if (Array.isArray(value)) return value;
  if (!value || typeof value !== 'object') return [];
  for (const key of ['chapters', 'bab', 'daftar_bab', 'sections', 'items', 'contents', 'data', 'list', 'hadis', 'hadiths', 'tafsir']) {
    if (Array.isArray(value[key])) return value[key];
  }
  for (const child of Object.values(value)) {
    if (child && typeof child === 'object' && !Array.isArray(child)) {
      const nested = arrayAt(child);
      if (nested.length) return nested;
    }
  }
  return [];
};
const asText = value => typeof value === 'string' ? value : (typeof value === 'number' ? String(value) : '');
function findField(item, keys, depth = 0) {
  if (!item || typeof item !== 'object' || depth > 3) return '';
  for (const key of keys) {
    const value = asText(item[key]);
    if (value.trim()) return value;
  }
  for (const value of Object.values(item)) {
    if (value && typeof value === 'object') {
      const found = findField(value, keys, depth + 1);
      if (found.trim()) return found;
    }
  }
  return '';
}
function normalizeChapter(item, index) {
  if (typeof item === 'string') {
    return { title: 'Bagian ' + (index + 1), arabic: ARABIC.test(item) ? item : '', translation: ARABIC.test(item) ? '' : item, latin: '' };
  }
  const title = findField(item, TITLE_KEYS).trim() || 'Bagian ' + (index + 1);
  let arabic = findField(item, ARABIC_KEYS);
  let latin = findField(item, LATIN_KEYS);
  let translation = findField(item, TRANSLATION_KEYS);
  // Be tolerant of manuscripts whose text is stored in a generic "text" field.
  if (!arabic || !translation) {
    const generic = findField(item, ['text', 'teks', 'body', 'paragraph']);
    if (generic) {
      if (ARABIC.test(generic) && !arabic) arabic = generic;
      else if (!translation) translation = generic;
    }
  }
  if (arabic && !ARABIC.test(arabic)) {
    if (!translation) translation = arabic;
    arabic = '';
  }
  return { title, arabic, latin, translation };
}
function appendMixedTranslation(container, value) {
  const paragraphs = String(value || '').split(/\n{2,}/);
  paragraphs.forEach(paragraph => {
    if (!paragraph.trim()) return;
    const arabicOnly = ARABIC.test(paragraph) && !/[A-Za-z]/.test(paragraph);
    const node = element('p', arabicOnly ? 'local-kitab-arabic' : 'local-kitab-translation', paragraph);
    node.dir = arabicOnly ? 'rtl' : 'auto';
    container.append(node);
  });
}
function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}
export function mountLocalKitabLibrary() {
  const home = document.getElementById('homePage');
  const search = document.getElementById('kitabLibrarySearch');
  const grid = document.getElementById('kitabLibraryGrid');
  if (!home || !search || !grid) return;
  grid.classList.add('collection-grid');
  const style = element('style');
  style.textContent = `
    .local-kitab-reader{display:none;max-width:980px;margin:0 auto;padding:22px 18px 36px;min-height:65vh}
    body.local-kitab-active .local-kitab-reader{display:block}
    body.local-kitab-active #homePage,body.local-kitab-active #readerMain,body.local-kitab-active #readerFooter{display:none!important}
    .local-kitab-top{display:flex;align-items:center;gap:12px;margin-bottom:16px}
    .local-kitab-back{border:1px solid #d6c9ad;border-radius:11px;background:#f4eddd;color:#234b37;padding:10px 13px;font-family:inherit;font-size:12px;font-weight:600}
    .local-kitab-paper{padding:clamp(18px,4vw,34px);border:1px solid #ded3ba;border-radius:20px;background:#fffaf0;color:#263b2e;min-height:55vh}
    .local-kitab-paper[data-mode="chapter"]{padding-bottom:112px}
    .local-kitab-paper h2{margin:0 0 8px;color:#174532;font:700 24px 'Amiri',serif}
    .local-kitab-intro{color:#827865;font-size:12px;line-height:1.7}
    .local-kitab-entry{padding:18px 0;border-bottom:1px solid #e4dac5}
    .local-kitab-bab{margin:22px 0 8px;padding:10px 12px;border-left:3px solid #bd9854;background:rgba(189,152,84,.10);color:#174532;font-size:13px;font-weight:700}
    .local-kitab-section-kicker{margin:0 0 4px;color:#9a824f;font-size:11px;font-weight:700;letter-spacing:.04em}
    .local-kitab-structured-arabic{direction:rtl;text-align:right;unicode-bidi:plaintext;font-family:'Amiri','Noto Naskh Arabic',serif;font-size:clamp(24px,4vw,29px);line-height:1.75;white-space:pre-wrap;margin:6px 0 8px}
    .local-kitab-structured-translation{direction:ltr;text-align:left;font-size:14px;line-height:1.7;font-style:italic;white-space:pre-wrap;margin:3px 0 8px;color:#554d40}
    .local-kitab-translation-label{margin:8px 0 2px;color:#9a824f;font-size:11px;font-weight:700;letter-spacing:.04em}
    .local-kitab-structured-mixed{direction:auto;text-align:start;font-size:15px;line-height:1.7;white-space:pre-wrap;margin:6px 0}
    body.theme-dark .local-kitab-bab{color:#f4e5bd;background:rgba(189,152,84,.13)}
    body.theme-dark .local-kitab-structured-translation{color:#e3d9c5}
    .local-kitab-entry h3{font-size:15px;color:#174532;margin:0 0 12px}
    .local-kitab-arabic{font-family:'Amiri','Noto Naskh Arabic',serif;font-size:27px;line-height:2.15;direction:rtl;unicode-bidi:plaintext;text-align:right;white-space:pre-wrap;margin:10px 0 20px}
    .local-kitab-latin,.local-kitab-translation{font-size:14px;line-height:2;white-space:pre-wrap;margin:10px 0}
    .local-kitab-latin{color:#82745e;font-style:italic}
    .local-kitab-join-prev{margin-top:0!important}
    .local-kitab-join-next{margin-bottom:0!important}
    .local-kitab-sentinel{text-align:center;margin:18px 0 0}
    .local-kitab-viewbar{display:flex;gap:6px;flex-wrap:wrap;margin:6px 0 14px}
    .local-kitab-viewbar button{min-height:40px;padding:6px 11px;border:1px solid #d8c9a8;border-radius:10px;background:#f0eadb;color:#34523f;font-size:12px;font-weight:600;font-family:inherit}
    .local-kitab-viewbar button[aria-pressed="true"]{background:#174a36;color:#fff7e5;border-color:#9a7a40}
    .local-kitab-viewbar .local-kitab-openall{margin-left:auto}
    .local-kitab-pair{padding:6px 0 12px;border-bottom:1px solid #e4dac5}
    .local-kitab-pair .local-kitab-arabic{margin:6px 0 4px}
    .local-kitab-fold{min-height:40px;padding:6px 12px;border:1px solid #d8c9a8;border-radius:10px;background:#f0eadb;color:#34523f;font-size:12px;font-weight:600;font-family:inherit}
    .local-kitab-fold-body{margin-top:6px;padding:4px 12px;border-right:3px solid #c9a95e;background:rgba(201,169,94,.08)}
    .local-kitab-fold-title{margin:4px 0 0;text-align:center;font-size:15px;font-weight:700;color:#174532}
    body.theme-dark .local-kitab-fold-title{color:#f4e5bd}
    body.theme-dark .local-kitab-pair{border-color:#465a49}
    body.theme-dark .local-kitab-viewbar button,body.theme-dark .local-kitab-fold{background:#304337;color:#eee4d0;border-color:#60745f}
    body.theme-dark .local-kitab-viewbar button[aria-pressed="true"]{background:#174a36;color:#fff7e5;border-color:#9a7a40}
    body.theme-dark .local-kitab-fold-body{background:rgba(201,169,94,.12)}
    .local-kitab-actions{display:flex;gap:8px;flex-wrap:wrap;margin:18px 0}
    .local-kitab-actions button,.local-kitab-open{border:1px solid #d8c9a8;border-radius:9px;padding:9px 12px;background:#f0eadb;color:#34523f;font-size:12px}
    .local-kitab-actions .primary,.local-kitab-open{background:#174a36;color:#fff7e5;border-color:#9a7a40}
    .local-kitab-floating-nav{position:fixed;left:50%;bottom:calc(18px + env(safe-area-inset-bottom));transform:translateX(-50%);z-index:1000;display:flex;align-items:center;justify-content:stretch;gap:6px;width:calc(100vw - 20px);max-width:560px;padding:5px;border:1px solid #d6c9ad;border-radius:13px;background:#fffaf0;box-shadow:0 5px 18px rgba(35,45,32,.16)}
    .local-kitab-floating-nav[hidden]{display:none}
    .local-kitab-floating-nav button{flex:1 1 0;min-width:0;min-height:42px;padding:8px 5px;border:1px solid #d8c9a8;border-radius:11px;background:#f0eadb;color:#234b37;font-family:inherit;font-size:11px;font-weight:700;white-space:normal;line-height:1.2}
    .local-kitab-floating-nav button.primary{background:#174a36;color:#fff7e5;border-color:#9a7a40}
    .local-kitab-floating-nav button:disabled{opacity:.78;filter:saturate(.65);cursor:not-allowed}
    body.theme-dark .local-kitab-floating-nav{background:#1d3026;border-color:#60745f;box-shadow:0 5px 18px rgba(0,0,0,.3)}
    body.theme-dark .local-kitab-floating-nav button{background:#304337;color:#eee4d0;border-color:#60745f}
    body.theme-dark .local-kitab-floating-nav button.primary{background:#174a36;color:#fff7e5;border-color:#9a7a40}
    @media(max-width:420px){.local-kitab-floating-nav{gap:4px;padding:6px}.local-kitab-floating-nav button{padding:8px 3px;font-size:9px}}
    body.theme-dark .local-kitab-paper{background:#1d3026;color:#eee4d0;border-color:#52634f}
    body.theme-dark .local-kitab-paper h2,body.theme-dark .local-kitab-entry h3{color:#f4e5bd}
    body.theme-dark .local-kitab-entry{border-color:#465a49}
    body.theme-dark .local-kitab-translation{color:#eee4d0}
    body.theme-dark .local-kitab-latin{color:#c0b69f}
    body.theme-dark .local-kitab-actions button{background:#304337;color:#eee4d0;border-color:#60745f}
    @media(max-width:480px){.local-kitab-reader{padding:14px 12px 28px}.local-kitab-paper{padding:17px 14px;border-radius:15px}.local-kitab-arabic{font-size:24px}}
  `;
  document.head.append(style);
  const reader = element('section', 'local-kitab-reader');
  const top = element('div', 'local-kitab-top');
  const back = element('button', 'local-kitab-back', '← Daftar kitab');
  back.type = 'button';
  const heading = element('strong', '', 'Perpustakaan Kitab Kuning');
  top.append(back, heading);
  const paper = element('article', 'local-kitab-paper');
  const chapterNav = element('nav', 'local-kitab-floating-nav');
  chapterNav.setAttribute('aria-label', 'Navigasi bab');
  chapterNav.hidden = true;
  reader.append(top, paper, chapterNav);
  reader.insertAdjacentHTML('beforeend', disclaimerMarkup);
  home.after(reader);
  let activeBook = null;
  let activeChapters = [];
  let activeIndex = 0;
  let activeLocalCopyAt = '';
  let stopLazy = () => {};
  let foldOpenAll = false;
  let foldSetters = [];
  function closeReader() {
    stopLazy();
    document.body.classList.remove('local-kitab-active');
    reader.hidden = true;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  function openReader(title) {
    stopLazy();
    heading.textContent = title;
    paper.replaceChildren(element('p', 'equran-loading', 'Memuat naskah lokal…'));
    reader.hidden = false;
    document.body.classList.add('local-kitab-active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  back.addEventListener('click', () => {
    if (activeBook && activeChapters.length && paper.dataset.mode === 'chapter') renderChapterList();
    else closeReader();
  });
  function renderChapterList() {
    stopLazy();
    paper.dataset.mode = 'list';
    chapterNav.hidden = true;
    window.scrollTo({ top: 0, behavior: 'auto' });
    chapterNav.replaceChildren();
    paper.replaceChildren(
      element('h2', '', activeBook.title),
      element('p', 'local-kitab-intro', activeChapters.length + ' bagian · Naskah tersimpan di folder data aplikasi dan dapat dibaca tanpa API kitab.'),
    );
    if (activeLocalCopyAt) {
      const notice = element('div', 'local-kitab-intro');
      notice.append(element('p', '', 'Menampilkan salinan lokal hasil edit di perangkat ini (' + activeLocalCopyAt + '). Salinan ini dipakai selama lebih baru daripada naskah di server.'));
      const useSource = element('button', 'local-kitab-open', 'Pakai naskah asli');
      useSource.type = 'button';
      useSource.addEventListener('click', () => {
        if (!window.confirm('Salinan lokal akan diarsipkan dan naskah asli dipakai. Lanjutkan?')) return;
        if (archiveLocalCopy(activeBook.slug)) openBook(activeBook);
      });
      notice.append(useSource);
      paper.append(notice);
    }
    const list = element('div', '');
    if (activeBook.format === 'structured') {
      let lastBab = '';
      activeChapters.forEach((section, index) => {
        if (section.chapterTitle !== lastBab) {
          lastBab = section.chapterTitle;
          list.append(element('h3', 'local-kitab-bab', lastBab));
        }
        const entry = element('article', 'local-kitab-entry');
        entry.append(element('h3', '', section.title));
        const open = element('button', 'local-kitab-open', 'Baca bagian');
        open.type = 'button';
        open.addEventListener('click', () => renderChapter(index));
        entry.append(open);
        list.append(entry);
      });
    } else {
      activeChapters.forEach((chapter, index) => {
        const entry = element('article', 'local-kitab-entry');
        entry.append(element('h3', '', (index + 1) + '. ' + chapter.title));
        const open = element('button', 'local-kitab-open', 'Baca bagian');
        open.type = 'button';
        open.addEventListener('click', () => renderChapter(index));
        entry.append(open);
        list.append(entry);
      });
    }
    if (activeBook.format === 'structured') {
      paper.append(list, element('p', 'local-kitab-intro', 'Edisi ini berdiri terpisah dari Safinah lama. Teks Arab dan terjemahan ditampilkan mengikuti urutan naskah DOCX sumber.'));
      return;
    }
    const actions = element('div', 'local-kitab-actions');
    const edit = element('button', 'primary', '✎ Edit naskah');
    edit.type = 'button';
    edit.addEventListener('click', () => {
      const openEditor = window.__EMOESLIFE_OPEN_KITAB_EDITOR__;
      if (typeof openEditor === 'function') {
        document.body.classList.remove('local-kitab-active');
        reader.hidden = true;
        openEditor(activeBook.slug, activeBook.title, activeChapters, () => {
          document.body.classList.remove('equran-reader-active');
          openBook(activeBook);
        });
      }
    });
    actions.append(edit);
    paper.append(list, actions, element('p', 'local-kitab-intro', 'Naskah asli di GitHub tidak diubah. Perubahan editor tersimpan sebagai salinan lokal; unduh JSON untuk memperbarui file sumber.'));
  }
  // Bab besar (ratusan ribu karakter) dirender bertahap saat pembaca menggulir, agar tidak membekukan HP.
  function renderChapterBody(chapter, view = 'both') {
    const queue = buildChapterQueue(chapter, view === 'classic' ? 'both' : view);
    foldSetters = [];
    const renderPair = (item, container) => {
      if (item.heading) {
        const head = element('div', 'local-kitab-pair local-kitab-pair-head');
        head.append(element('p', 'local-kitab-fold-title', item.translation));
        head.append(element('p', 'local-kitab-arabic', item.arabic));
        container.append(head);
        return;
      }
      const card = element('div', 'local-kitab-pair');
      card.append(element('p', 'local-kitab-arabic', item.arabic));
      const toggle = element('button', 'local-kitab-fold', 'Lihat terjemah');
      toggle.type = 'button';
      toggle.setAttribute('aria-expanded', 'false');
      card.append(toggle);
      let body = null;
      const setOpen = open => {
        if (open && !body) { body = element('div', 'local-kitab-fold-body'); appendMixedTranslation(body, item.translation); card.append(body); }
        if (body) body.hidden = !open;
        toggle.textContent = open ? 'Sembunyikan terjemah' : 'Lihat terjemah';
        toggle.setAttribute('aria-expanded', String(open));
      };
      toggle.addEventListener('click', () => setOpen(!body || body.hidden));
      foldSetters.push(setOpen);
      if (foldOpenAll) setOpen(true);
      container.append(card);
    };
    const renderItem = (item, container) => {
      if (item.kind === 'pair') { renderPair(item, container); return; }
      if (item.kind === 'translation') { appendMixedTranslation(container, item.chunk); return; }
      const node = element('p', item.kind === 'arabic' ? 'local-kitab-arabic' : 'local-kitab-latin', item.chunk);
      if (!item.first) node.classList.add('local-kitab-join-prev');
      if (!item.last) node.classList.add('local-kitab-join-next');
      container.append(node);
    };
    queue.splice(0, planBatch(queue)).forEach(item => renderItem(item, paper));
    if (!queue.length) return;
    const sentinel = element('p', 'local-kitab-intro local-kitab-sentinel', 'Gulir untuk memuat lanjutan bab…');
    paper.append(sentinel);
    let frame = 0;
    let observer = null;
    const nearViewport = () => sentinel.getBoundingClientRect().top < window.innerHeight + 1500;
    const fill = () => {
      if (stopLazy !== teardown) return; // callback usang dari bab sebelumnya: abaikan
      frame = 0;
      while (queue.length && nearViewport()) {
        const fragment = document.createDocumentFragment();
        queue.splice(0, planBatch(queue)).forEach(item => renderItem(item, fragment));
        paper.insertBefore(fragment, sentinel);
      }
      if (!queue.length) teardown();
    };
    const schedule = () => { if (!frame) frame = window.requestAnimationFrame(fill); };
    if (typeof IntersectionObserver === 'function') {
      observer = new IntersectionObserver(entries => { if (entries.some(entry => entry.isIntersecting)) schedule(); }, { rootMargin: '1500px 0px' });
      observer.observe(sentinel);
    } else {
      window.addEventListener('scroll', schedule, { passive: true });
    }
    function teardown() {
      if (frame) window.cancelAnimationFrame(frame);
      frame = 0;
      observer?.disconnect();
      window.removeEventListener('scroll', schedule);
      sentinel.remove();
      queue.length = 0;
      stopLazy = () => {};
    }
    stopLazy = teardown;
    schedule();
  }
  function renderChapter(index) {
    activeIndex = index;
    const chapter = activeChapters[index];
    window.scrollTo({ top: 0, behavior: 'auto' });
    paper.dataset.mode = 'chapter';
    chapterNav.hidden = false;
    paper.replaceChildren(element('h2', '', chapter.title));
    stopLazy();
    foldOpenAll = false;
    if (activeBook.format === 'structured') {
      paper.append(element('p', 'local-kitab-section-kicker', chapter.chapterTitle));
      for (const block of chapter.blocks || []) {
        if (block.type === 'translation-label') {
          paper.append(element('p', 'local-kitab-translation-label', block.text));
        } else if (block.type === 'arabic') {
          const node = element('p', 'local-kitab-structured-arabic', block.text);
          node.dir = 'rtl';
          paper.append(node);
        } else if (block.type === 'translation') {
          const node = element('p', 'local-kitab-structured-translation', block.text);
          node.dir = 'ltr';
          paper.append(node);
        } else {
          const node = element('p', 'local-kitab-structured-mixed', block.text);
          node.dir = 'auto';
          paper.append(node);
        }
      }
    } else {
    const resolved = resolveView(chapter, readViewPrefs());
    if (resolved.options.length) {
      const bar = element('div', 'local-kitab-viewbar');
      resolved.options.forEach(option => {
        const choice = element('button', '', VIEW_LABELS[option]);
        choice.type = 'button';
        choice.setAttribute('aria-pressed', String(option === resolved.view));
        choice.addEventListener('click', () => {
          if (option === resolved.view) return;
          writeViewPref(resolved.options.includes('fold') ? 'paired' : 'unpaired', option);
          renderChapter(index);
        });
        bar.append(choice);
      });
      if (resolved.view === 'fold') {
        const openAll = element('button', 'local-kitab-openall', 'Buka semua');
        openAll.type = 'button';
        openAll.addEventListener('click', () => {
          foldOpenAll = !foldOpenAll;
          foldSetters.forEach(setOpen => setOpen(foldOpenAll));
          openAll.textContent = foldOpenAll ? 'Tutup semua' : 'Buka semua';
        });
        bar.append(openAll);
      }
      paper.append(bar);
    }
    renderChapterBody(chapter, resolved.view);
    if (!chapter.arabic && !chapter.translation && !chapter.latin) {
      paper.append(element('p', 'local-kitab-intro', 'Bagian ini tidak memiliki field teks yang dikenali. Naskah JSON asli tetap dipertahankan.'));
    }
    }
    chapterNav.replaceChildren();
    const listButton = element('button', '', activeBook.format === 'structured' ? 'Daftar Isi' : 'Daftar Bab');
    listButton.type = 'button';
    listButton.addEventListener('click', renderChapterList);
    const previous = element('button', '', activeBook.format === 'structured' ? '← Bagian Sebelumnya' : '← Bab Sebelumnya');
    previous.type = 'button';
    previous.disabled = index === 0;
    previous.addEventListener('click', () => renderChapter(index - 1));
    const next = element('button', 'primary', activeBook.format === 'structured' ? 'Bagian Selanjutnya →' : 'Bab Selanjutnya →');
    next.type = 'button';
    next.disabled = index >= activeChapters.length - 1;
    next.addEventListener('click', () => renderChapter(index + 1));
    chapterNav.append(listButton, previous, next);
  }
  async function openBook(book) {
    activeBook = book;
    openReader(book.title);
    try {
      const response = await fetch('./data/' + book.file);
      if (!response.ok) throw new Error('File ' + book.file + ' tidak dapat dimuat (' + response.status + ').');
      const documentData = await response.json();
      if (book.format === 'structured') {
        if (!Array.isArray(documentData.chapters) || !documentData.chapters.length) throw new Error('Struktur BAB Safinah belum dikenali.');
        activeChapters = documentData.chapters.flatMap((bab, babIndex) =>
          (Array.isArray(bab.sections) ? bab.sections : []).map((section, sectionIndex) => ({
            title: section.title || ('Bagian ' + (sectionIndex + 1)),
            chapterTitle: bab.title || ('BAB ' + (babIndex + 1)),
            chapterNumber: bab.number || String(babIndex + 1),
            blocks: Array.isArray(section.blocks) ? section.blocks : []
          }))
        );
        if (!activeChapters.length) throw new Error('Naskah Safinah belum memiliki bagian bacaan.');
      } else {
        const rawChapters = arrayAt(documentData);
        if (!rawChapters.length) throw new Error('Struktur naskah ' + book.file + ' belum dikenali.');
        activeChapters = rawChapters.map(normalizeChapter);
      }
      activeLocalCopyAt = '';
      try {
        if (book.format === 'structured') throw new Error('Edisi terstruktur memakai naskah sumber tetap.');
        const saved = JSON.parse(localStorage.getItem(manualKey(book.slug)) || 'null');
        if (shouldUseLocalCopy(saved, documentData)) {
          activeChapters = saved.chapters.map(normalizeChapter);
          activeLocalCopyAt = saved.updatedAt || 'tanggal tidak diketahui';
        } else if (saved) {
          // Naskah di server lebih baru daripada edit terakhir: arsipkan salinan usang agar editor memakai naskah baru.
          archiveLocalCopy(book.slug);
        }
      } catch (error) { console.warn('Salinan lokal kitab tidak dapat dibaca.', error); }
      if (!activeChapters.length) throw new Error('Naskah belum memiliki bagian bacaan.');
      renderChapterList();
    } catch (error) {
      paper.replaceChildren(element('h2', '', book.title), element('p', 'local-kitab-intro', error.message || 'Naskah gagal dimuat.'));
    }
  }
  function drawCatalog() {
    const query = search.value.trim().toLocaleLowerCase('id');
    grid.replaceChildren();
    const entries = [
      ...BOOKS.map(book => ({ ...book, source: 'local' })),
      ...apiBooks.map(book => ({ ...book, source: 'api' }))
    ];
    const filtered = entries.filter(book =>
      (book.title + ' ' + book.category + ' ' + book.slug).toLocaleLowerCase('id').includes(query)
    );
    filtered.forEach((book, index) => {
      const card = element('button', 'collection-card local-kitab-card');
      card.type = 'button';
      const iconWrap = element('span', 'collection-symbol');
      const iconImage = element('img');
      iconImage.src = '/assets/collection-icon.webp';
      iconImage.alt = '';
      iconImage.setAttribute('aria-hidden', 'true');
      iconWrap.append(iconImage);
      const bottom = element('span', 'collection-bottom');
      bottom.append(
        element('span', 'collection-meta', (book.category || 'Kitab klasik') + ' · ' + (book.source === 'local' ? 'Naskah lokal' : 'Sumber sementara')),
        element('span', 'round-arrow')
      );
      card.append(
        element('span', 'card-index', String(index + 1).padStart(2, '0') + ' / KITAB KLASIK'),
        iconWrap,
        element('span', 'collection-title', book.title),
        element('span', 'collection-desc', book.format === 'structured' ? 'Edisi baru · 6 BAB · 63 bagian, terpisah dari naskah lama.' : (book.source === 'local' ? 'Baca naskah kitab yang tersimpan di aplikasi.' : 'Baca kitab melalui sumber API sementara.')),
        bottom
      );
      card.addEventListener('click', () => {
        if (book.source === 'local') openBook(book);
        else window.__EMOESLIFE_OPEN_API_KITAB__?.(book.slug, book.title);
      });
      grid.append(card);
    });
    if (!filtered.length) grid.append(element('p', 'equran-loading', 'Kitab tidak ditemukan.'));
  }
  search.addEventListener('input', drawCatalog);
  drawCatalog();

  // Keep API books available until their curated local JSON files are uploaded.
  const loadApiCatalog = window.__EMOESLIFE_LOAD_API_KITAB__;
  if (typeof loadApiCatalog === 'function') {
    loadApiCatalog().then(remoteBooks => {
      const localSlugs = new Set(BOOKS.flatMap(book => [book.slug, ...(book.slug === 'safinah-an-najah' ? ['safinah'] : [])]));
      const localTitles = new Set(BOOKS.map(book => normalizeBookName(book.title)));
      apiBooks = (Array.isArray(remoteBooks) ? remoteBooks : []).filter(book =>
        book.slug &&
        !localSlugs.has(book.slug) &&
        !localTitles.has(normalizeBookName(book.title))
      );
      drawCatalog();
    }).catch(error => {
      console.warn('Katalog API kitab sementara tidak dapat dimuat; naskah lokal tetap tersedia.', error);
    });
  }
}
