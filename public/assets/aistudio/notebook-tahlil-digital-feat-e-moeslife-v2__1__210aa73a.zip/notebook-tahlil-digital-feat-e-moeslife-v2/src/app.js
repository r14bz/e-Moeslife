import { sections, loadAdditionalSurahs } from './data/sections.js';
import { mountAppShell } from './components/app-shell.js';
import { registerOfflineSupport } from './services/offline/register-service-worker.js';
import { readPreference, writePreference, readJsonPreference, writeJsonPreference } from './services/storage/preferences.js';
import { getReadingGroup } from './features/reader/navigation.js';
import { getReadingGroupBounds, getPageProgress } from './features/reader/page-state.js';
import { prepareReadingSections, completeSectionStarts } from './features/reader/sections.js';
import { renderReaderContents } from './features/reader/contents.js';
import { createReaderController } from './features/reader/controller.js';
import { loadOptionalReaderContent } from './features/reader/content-loader.js';
import { getSwipeDirection } from './features/reader/gestures.js';
import { applyReaderTheme, applyReaderFontSize } from './features/reader/appearance.js';
import { splitSectionForScreen } from './features/reader/pagination.js';
import { renderReadingList } from './features/home/reading-list.js';
import { findCollectionStart } from './features/collections/navigation.js';
import { initPrayerTimes } from './features/prayer/prayer-times.js';
import { checkForAppUpdate } from './services/app-update.js';
import { mountIslamicLibrary } from './features/library/equran-library.js';
import { mountLocalKitabLibrary } from './features/library/local-kitab-library.js';

mountAppShell();
initPrayerTimes();
registerOfflineSupport();
// Check the latest signed Android release without blocking app startup or offline reading.
checkForAppUpdate();
window.__EMOESLIFE_LOCAL_KITAB__ = true;
mountIslamicLibrary();
mountLocalKitabLibrary();

const $=id=>document.getElementById(id);
let pages=[],index=0,sectionStarts=[],layoutPass=0,readerViewRequested=false,pendingReaderSection=null,pendingCollection=null,readerContentReady=false;
const readPageLayout=()=>{
 const value=readJsonPreference('pageLayout', {});
 return value&&typeof value==='object'&&!Array.isArray(value)?value:{};
};
const readSavedPageIndex=()=>{
 const value=Number.parseInt(readPreference('page','0'),10);
 return Number.isSafeInteger(value)&&value>=0?value:0;
};

function buildPages(){
 const pass=++layoutPass;
 document.body.classList.add('reader-active');
 const saved=readSavedPageIndex(),currentPage=pages[index],currentSection=currentPage?.sectionIndex;
 const currentSectionOffset=currentSection===undefined?0:pages.slice(0,index).filter(page=>page.sectionIndex===currentSection).length;
 const paper=$('paper'),text=$('arabicText');
 $('pageTitle').textContent='Mengukur halaman';text.textContent='بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ';
 requestAnimationFrame(()=>{
  if(pass!==layoutPass)return;
  const available=Math.max(90,paper.clientHeight-$('pageTitle').offsetHeight-$('pageTitle').offsetTop-85);
  const width=Math.max(100,text.clientWidth);
  pages=[];sectionStarts=[];
  // Kelompok Tahlil sudah ditentukan di data; jangan gabungkan ulang berdasarkan panjang teks.
  const pageLayout=readPageLayout();
  const readingSections=prepareReadingSections(sections,pageLayout);
  readingSections.forEach(s=>{
   const originalIndex=s.originalIndex;
   sectionStarts[originalIndex]=pages.length;
   pages.push(...splitSectionForScreen(s,originalIndex,available,width,text));
  });
  sectionStarts=completeSectionStarts(sectionStarts,sections.length);
  const sectionPages=currentSection===undefined?[]:pages.reduce((matches,page,pageIndex)=>{
   if(page.sectionIndex===currentSection)matches.push(pageIndex);
   return matches;
  },[]);
  index=sectionPages.length?sectionPages[Math.min(currentSectionOffset,sectionPages.length-1)]:Math.min(saved,Math.max(0,pages.length-1));
  showPage(index);
  if(pendingReaderSection!==null){const target=pendingReaderSection;pendingReaderSection=null;showPage(Math.max(0,sectionStarts[target]??0));}
  // Jangan sembunyikan reader jika pengguna sudah meminta membuka koleksi saat layout masih dihitung.
  if(!readerViewRequested)document.body.classList.remove('reader-active');
 });
}
function activateReader(sectionIndex){
 readerViewRequested=true;
 if(!pages.length){pendingReaderSection=sectionIndex;readerViewRequested=true;buildPages();return;}
 // Pastikan indeks awal benar-benar menunjuk section yang diminta.
 // Indeks lama bisa berubah ketika data surah opsional dimuat di depan daftar.
 const mappedStart=sectionStarts[sectionIndex];
 const start=Number.isInteger(mappedStart)&&pages[mappedStart]?.sectionIndex===sectionIndex
  ? mappedStart
  : pages.findIndex(page=>page.sectionIndex===sectionIndex);
 if(start<0){readerViewRequested=false;return;}
 document.body.classList.add('reader-active');
 showPage(start);
 window.scrollTo({top:0,behavior:'smooth'});
}
const renderHome = () => renderReadingList({ sections, pages, $, activateReader });
function openCollection(kind){
 // Tunggu sampai daftar section dan halaman selesai memakai urutan data yang sama.
 if(!readerContentReady){pendingCollection=kind;return;}
 const first=findCollectionStart(sections,kind);
 if(first<0)return;
 const target=sections[first];
 const pageSetMatches=pages.some(page=>
  page.sectionIndex===first&&page.title===target.title&&
  page.quranSurah===target.quranSurah&&page.collection===target.collection
 );
 if(!pageSetMatches){
  pendingReaderSection=first;
  readerViewRequested=true;
  buildPages();
  return;
 }
 activateReader(first);
}
document.querySelectorAll('[data-home-target]').forEach(b=>b.addEventListener('click',()=>{if(b.classList.contains('is-activating'))return;b.classList.add('is-activating');window.setTimeout(()=>openCollection(b.dataset.homeTarget),150);window.setTimeout(()=>b.classList.remove('is-activating'),420)}));
$('homeSearch').addEventListener('input',renderHome);
const renderContents=()=>renderReaderContents({sections,pages,index,sectionStarts,$,showPage});
const readerController=createReaderController({
 getPages:()=>pages,getIndex:()=>index,setIndex:value=>{index=value;},$,writePreference,renderContents,
 getReadingGroup,getReadingGroupBounds,getPageProgress
});
const showPage=(...args)=>readerController.showPage(...args);
const continueReadingButton = $('continueReadingBtn');
if(continueReadingButton)continueReadingButton.addEventListener('click',()=>{
 if(!pages.length)return;
 const saved=readSavedPageIndex();
 readerViewRequested=true;
 document.body.classList.add('reader-active');
 showPage(Math.min(saved,pages.length-1));
 window.scrollTo({top:0,behavior:'smooth'});
});
const next=()=>readerController.next();
const prev=()=>readerController.prev();
const isPageTurning=()=>readerController.isTurning();
$('nextBtn').onclick=next;$('prevBtn').onclick=prev;

$('homeBtn').onclick=()=>{readerViewRequested=false;document.body.classList.remove('reader-active','toc-open');$('contentsBtn').setAttribute('aria-expanded','false');window.scrollTo({top:0,behavior:'smooth'});renderHome()};
$('contentsBtn').onclick=()=>{
 const open=!document.body.classList.contains('toc-open');
 if(open){readerViewRequested=true;document.body.classList.add('reader-active');renderContents();}
 document.body.classList.toggle('toc-open',open);
 $('contentsBtn').setAttribute('aria-expanded',String(open));
};
$('closeContents').onclick=()=>{document.body.classList.remove('toc-open');$('contentsBtn').setAttribute('aria-expanded','false')};
const applyTheme=theme=>applyReaderTheme(theme,{body:document.body,button:$('themeBtn'),writePreference});
$('themeBtn').onclick=()=>applyTheme(document.body.classList.contains('theme-dark')?'light':'dark');
applyTheme(readPreference('theme')==='dark'?'dark':'light');

// Swipe navigation on the paper: swipe left for next, right for previous.
(function enablePaperSwipe(){
 const paper=$('paper');let startX=0,startY=0,startTime=0;
 paper.addEventListener('touchstart',e=>{
  if(e.touches.length!==1||document.body.classList.contains('toc-open'))return;
  startX=e.touches[0].clientX;startY=e.touches[0].clientY;startTime=Date.now();
 },{passive:true});
 paper.addEventListener('touchend',e=>{
  if(!startTime||!e.changedTouches.length||isPageTurning())return;
  const dx=e.changedTouches[0].clientX-startX,dy=e.changedTouches[0].clientY-startY,duration=Date.now()-startTime;
  startTime=0;
  const direction=getSwipeDirection({dx,dy,duration});
  if(direction==='next')next();
  else if(direction==='prev')prev();
 },{passive:true});
 paper.setAttribute('aria-label','Halaman bacaan. Geser ke kiri untuk halaman berikutnya, geser ke kanan untuk halaman sebelumnya.');
 const left=document.createElement('button');left.type='button';left.className='swipe-hint swipe-hint-left';left.setAttribute('aria-label','Halaman sebelumnya');left.title='Halaman sebelumnya';left.textContent='‹';left.onclick=e=>{e.stopPropagation();left.classList.add('hint-tapped');prev();window.setTimeout(()=>left.classList.remove('hint-tapped'),80)};
 const right=document.createElement('button');right.type='button';right.className='swipe-hint swipe-hint-right';right.setAttribute('aria-label','Halaman berikutnya');right.title='Halaman berikutnya';right.textContent='›';right.onclick=e=>{e.stopPropagation();right.classList.add('hint-tapped');next();window.setTimeout(()=>right.classList.remove('hint-tapped'),80)};
 paper.append(left,right);
 [left,right].forEach(hint=>hint.addEventListener('click',()=>{hint.classList.add('hint-fading');window.setTimeout(()=>hint.classList.remove('hint-fading'),80)}));
})();

const applyFontSize=value=>applyReaderFontSize(value,{body:document.body,control:$('fontSize'),arabicText:$('arabicText'),writePreference});
$('fontSize').onchange=e=>{applyFontSize(e.target.value);buildPages()};
// Fullscreen control has been replaced by the theme toggle; do not bind the removed button.
document.body.classList.remove('reader-active','toc-open');$('contentsBtn').setAttribute('aria-expanded','false');
applyFontSize(readPreference('fontSize','normal'));
// Render local content immediately so taps work even while optional surah data is loading.
buildPages();renderHome();
loadOptionalReaderContent({
 sections,loadAdditionalSurahs,fetchImpl:fetch,
 readPageLayout,
 writePageLayout:layout=>writeJsonPreference('pageLayout',layout)
}).then(()=>{
 // Optional files are isolated: the local reader remains usable if either one is unavailable.
 readerContentReady=true;
 buildPages();renderHome();
 if(pendingCollection){const kind=pendingCollection;pendingCollection=null;openCollection(kind);}
}).catch(()=>{
 // Keep the bundled reading sections available even if optional content cannot be loaded.
 readerContentReady=true;
 buildPages();renderHome();
 if(pendingCollection){const kind=pendingCollection;pendingCollection=null;openCollection(kind);}
});
window.addEventListener('resize',()=>{if(!document.body.classList.contains('reader-active'))return;clearTimeout(window.__tahlilResize);window.__tahlilResize=setTimeout(buildPages,220)});
if(document.fonts?.ready)document.fonts.ready.then(()=>setTimeout(()=>{if(document.body.classList.contains('reader-active'))buildPages()},80));
