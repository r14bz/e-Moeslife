import { readFile, access } from 'node:fs/promises';
import path from 'node:path';

const root = process.cwd();
const output = path.join(root, 'www');

// Validate every curated manuscript referenced by the local kitab catalog.
// This catches missing uploads, malformed JSON, and unexpected top-level structures
// before a PWA/APK build is considered ready.
const localLibrary = await readFile(path.join(root, 'src/features/library/local-kitab-library.js'), 'utf8');
const kitabFiles = [...localLibrary.matchAll(/\{\s*file:\s*'([^']+)'/g)].map(([, file]) => file);
if (!kitabFiles.length) throw new Error('No local kitab JSON files are declared in the catalog.');

for (const file of kitabFiles) {
  const sourcePath = path.join(output, 'data', file);
  let documentData;
  try {
    const source = (await readFile(sourcePath, 'utf8')).replace(/^\uFEFF/, '');
    documentData = JSON.parse(source);
  } catch (error) {
    throw new Error('Local kitab JSON is missing or invalid: data/' + file + ' (' + error.message + ')');
  }
  if (!Array.isArray(documentData.chapters) || documentData.chapters.length === 0) {
    throw new Error('Local kitab JSON must contain a non-empty chapters array: data/' + file);
  }
}
console.log('Verified ' + kitabFiles.length + ' local kitab JSON manuscripts in ./www/data');
const worker = await readFile(path.join(root, 'service-worker.js'), 'utf8');
const match = worker.match(/const CORE_ASSETS = \[([\s\S]*?)\];/);

if (!match) throw new Error('Could not locate CORE_ASSETS in service-worker.js');

const assets = [...match[1].matchAll(/'([^']+)'/g)].map(([, asset]) => asset);
if (!assets.length) throw new Error('CORE_ASSETS is empty; offline shell would have no precached files');

const missing = [];
for (const asset of assets) {
  const relative = asset.replace(/^\/+/, '');
  try {
    await access(path.join(output, relative));
  } catch {
    missing.push(asset);
  }
}

if (missing.length) {
  console.error('Missing offline precache assets:');
  for (const asset of missing) console.error(' - ' + asset);
  process.exitCode = 1;
} else {
  console.log('Verified all ' + assets.length + ' service-worker precache assets in ./www');
}

const precached = new Set(assets);
const visitedModules = new Set();
const missingImports = [];

async function verifyImportedModules(asset) {
  if (visitedModules.has(asset)) return;
  visitedModules.add(asset);
  const relative = asset.replace(/^\/+/, '');
  const source = await readFile(path.join(output, relative), 'utf8');
  const imports = [...source.matchAll(/\bfrom\s*['"]([^'"]+)['"]/g)].map(([, specifier]) => specifier);

  for (const specifier of imports) {
    if (!specifier.startsWith('.')) continue;
    const importedPath = path.posix.resolve(path.posix.dirname(asset), specifier);
    const importedAsset = importedPath.startsWith('/') ? importedPath : '/' + importedPath;
    if (!precached.has(importedAsset)) missingImports.push({ importer: asset, imported: importedAsset });
    await verifyImportedModules(importedAsset);
  }
}

await verifyImportedModules('/src/app.js');

if (missingImports.length) {
  console.error('Local JavaScript modules imported by the app but missing from service-worker precache:');
  for (const item of missingImports) console.error(' - ' + item.importer + ' -> ' + item.imported);
  process.exitCode = 1;
} else {
  console.log('Verified all ' + visitedModules.size + ' local JavaScript modules imported by the app are included in the offline precache');
}
