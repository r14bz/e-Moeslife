import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';

import { getReadingGroup } from '../src/features/reader/navigation.js';
import { getSwipeDirection } from '../src/features/reader/gestures.js';
import { getReadingGroupBounds, getPageProgress } from '../src/features/reader/page-state.js';
import { applyReaderTheme, applyReaderFontSize } from '../src/features/reader/appearance.js';
import { prepareReadingSections, completeSectionStarts } from '../src/features/reader/sections.js';
import { getReaderContentsGroups } from '../src/features/reader/contents.js';
import { createReaderController } from '../src/features/reader/controller.js';
import { readerPageMarkup } from '../src/components/shell/reader-page.js';

import { buildQariAyahUrls, splitSpeechText, createReaderAudioController } from '../src/features/reader/audio.js';
import { applyDzikirOverrides, isValidManualDzikirLayout, loadOptionalReaderContent } from '../src/features/reader/content-loader.js';

import { getZoneForProvince, shouldRetryRefresh } from '../src/features/prayer/prayer-times.js';
import { shouldUseLocalCopy, chunkText, buildChapterQueue, planBatch, pairParagraphs, resolveView, splitParagraphs } from '../src/features/library/local-kitab-library.js';
import { filterReadingSections } from '../src/features/home/search.js';
import { findCollectionStart } from '../src/features/collections/navigation.js';
import {
  readPreference,
  writePreference,
  readJsonPreference,
  writeJsonPreference
} from '../src/services/storage/preferences.js';


test('audio helpers build complete qari ayah playlists for supported surahs', () => {
  const yasin = buildQariAyahUrls(36);
  const rahman = buildQariAyahUrls(55);
  assert.equal(yasin.length, 83);
  assert.equal(yasin[0], 'https://everyayah.com/data/Alafasy_128kbps/036001.mp3');
  assert.equal(yasin.at(-1), 'https://everyayah.com/data/Alafasy_128kbps/036083.mp3');
  assert.equal(rahman.length, 78);
  assert.equal(rahman.at(-1), 'https://everyayah.com/data/Alafasy_128kbps/055078.mp3');
  assert.deepEqual(buildQariAyahUrls(2), []);
  assert.deepEqual(buildQariAyahUrls(36, 'unknown'), []);
});

test('speech text is chunked at word boundaries without losing content', () => {
  const text = 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ '.repeat(30);
  const chunks = splitSpeechText(text, 80);
  assert.ok(chunks.length > 1);
  assert.ok(chunks.every(chunk => chunk.length <= 80));
  assert.equal(chunks.join(' '), text.trim());
  assert.deepEqual(splitSpeechText('   '), []);
});

test('reader audio controller sequences qari ayat and stops when changing surah', async () => {
  const handlers = {};
  const audio = {
    src: '',
    paused: true,
    addEventListener(name, callback) { handlers[name] = callback; },
    removeAttribute(name) { if (name === 'src') this.src = ''; },
    load() {},
    pause() { this.paused = true; },
    async play() { this.paused = false; }
  };
  const button = { disabled: true, title: '' };
  const status = { textContent: '' };
  const controller = createReaderAudioController({
    audioElement: audio,
    qariButton: button,
    statusElement: status
  });

  controller.update({ quranSurah: 36 });
  assert.equal(button.disabled, false);
  assert.equal(await controller.playQari({ quranSurah: 36 }), true);
  assert.match(audio.src, /036001\.mp3$/);
  await handlers.ended();
  assert.match(audio.src, /036002\.mp3$/);

  controller.update({ quranSurah: 55 });
  assert.equal(audio.src, '');
  assert.equal(button.disabled, false);
  controller.update({ title: 'Tahlil' });
  assert.equal(button.disabled, true);
  assert.match(button.title, /Yasin dan Ar-Rahman/);
});

test('reader audio reports unavailable speech support without throwing', () => {
  const status = { textContent: '' };
  const controller = createReaderAudioController({ statusElement: status });
  assert.equal(controller.speak('بِسْمِ اللَّهِ'), false);
  assert.match(status.textContent, /TTS tidak tersedia/);
});

test('dzikir overrides apply only valid text entries to dzikir sections', () => {
  const sections = [
    { title: 'Tahlil' },
    { title: 'Dzikir 1', collection: 'dzikir', text: 'lama' },
    { title: 'Dzikir 2', collection: 'dzikir', text: 'lama 2' }
  ];
  const count = applyDzikirOverrides(sections, {
    sections: [{ text: 'baru' }, { text: '' }, { text: 'jangan diterapkan' }]
  });
  assert.equal(count, 1);
  assert.equal(sections[1].text, 'baru');
  assert.equal(sections[2].text, 'lama 2');
  assert.equal(applyDzikirOverrides(sections, {}), 0);
});

test('manual dzikir page layout accepts only the exported supported format', () => {
  assert.equal(isValidManualDzikirLayout({
    format: 'etahlil-dzikir-page-layout',
    scope: 'dzikir-ba-da-shalat',
    sectionIndex: 3,
    text: 'bagian 1\n[[HALAMAN BARU]]\nbagian 2'
  }), true);
  assert.equal(isValidManualDzikirLayout({ format: 'other', scope: 'dzikir-ba-da-shalat', sectionIndex: 3, text: 'x [[HALAMAN BARU]] y' }), false);
  assert.equal(isValidManualDzikirLayout({ format: 'etahlil-dzikir-page-layout', scope: 'dzikir-ba-da-shalat', sectionIndex: -1, text: 'x [[HALAMAN BARU]] y' }), false);
});

test('optional reader content loads independently and returns recoverable file errors', async () => {
  const sections = [{ title: 'Dzikir', collection: 'dzikir', text: 'lama' }];
  let savedLayout = null;
  const result = await loadOptionalReaderContent({
    sections,
    loadAdditionalSurahs: async () => {},
    fetchImpl: async url => {
      if (url.includes('dzikir-overrides')) return { ok: true, json: async () => ({ sections: [{ text: 'teks terbaru' }] }) };
      return { ok: false, status: 404 };
    },
    readPageLayout: () => ({}),
    writePageLayout: value => { savedLayout = value; }
  });
  assert.equal(result.overridesApplied, 1);
  assert.equal(sections[0].text, 'teks terbaru');
  assert.equal(result.pageLayoutApplied, false);
  assert.equal(result.errors.length, 1);
  assert.equal(savedLayout, null);
});

test('reader navigation keeps Quran surahs and collections in separate groups', () => {
  assert.equal(getReadingGroup({ quranSurah: 36 }), 'quran-36');
  assert.equal(getReadingGroup({ quranSurah: 55 }), 'quran-55');
  assert.equal(getReadingGroup({ collection: 'dzikir' }), 'dzikir');
  assert.equal(getReadingGroup({}), 'tahlil');
  assert.equal(getReadingGroup(null), 'tahlil');
});

test('search filters by localized title and retains original indexes', () => {
  const sections = [
    { title: 'Pembukaan Tahlil' },
    { title: 'Surah Yasin', quranSurah: 36 },
    { title: 'Dzikir Pagi', collection: 'dzikir' }
  ];

  assert.deepEqual(
    filterReadingSections(sections, '  yAsIn  ').map(({ s, i }) => [s.title, i]),
    [['Surah Yasin', 1]]
  );
  assert.deepEqual(
    filterReadingSections(sections, '', section => section.collection === 'dzikir').map(({ i }) => i),
    [2]
  );
  assert.equal(filterReadingSections(sections, 'tidak ditemukan').length, 0);
});

test('collection shortcuts resolve the first matching section', () => {
  const sections = [
    { title: 'Tahlil awal' },
    { collection: 'dzikir' },
    { quranSurah: 36 },
    { quranSurah: 55 },
    { collection: 'dzikir' }
  ];

  assert.equal(findCollectionStart(sections, 'tahlil'), 0);
  assert.equal(findCollectionStart(sections, 'dzikir'), 1);
  assert.equal(findCollectionStart(sections, 'yasin'), 2);
  assert.equal(findCollectionStart(sections, 'rahman'), 3);
  assert.equal(findCollectionStart(sections, 'unknown'), -1);
});

test('preferences persist through localStorage using mapped keys', () => {
  const values = new Map();
  globalThis.localStorage = {
    getItem: key => values.has(key) ? values.get(key) : null,
    setItem: (key, value) => values.set(key, String(value))
  };

  assert.equal(writePreference('page', 12), true);
  assert.equal(values.get('tahlil-page'), '12');
  assert.equal(readPreference('page'), '12');
  assert.equal(readPreference('missing-key', 'fallback'), 'fallback');
  assert.equal(writePreference('ttsVoice', 'arabic-voice'), true);
  assert.equal(values.get('etahlil-tts-voice-v1'), 'arabic-voice');
  assert.equal(readPreference('ttsVoice'), 'arabic-voice');
});

test('preferences use memory fallback when browser storage is unavailable', () => {
  const key = 'test-memory-fallback';
  globalThis.localStorage = {
    getItem() { throw new Error('storage blocked'); },
    setItem() { throw new Error('storage blocked'); }
  };

  assert.equal(writePreference(key, 'remembered'), false);
  assert.equal(readPreference(key), 'remembered');
  assert.equal(readPreference('never-written', 'safe-default'), 'safe-default');
});

test('JSON preferences return fallback for malformed JSON', () => {
  globalThis.localStorage = {
    getItem: () => '{broken',
    setItem() {}
  };

  assert.deepEqual(readJsonPreference('test-invalid-json', { safe: true }), { safe: true });
});

test('JSON preferences serialize and restore structured values', () => {
  const values = new Map();
  globalThis.localStorage = {
    getItem: key => values.has(key) ? values.get(key) : null,
    setItem: (key, value) => values.set(key, String(value))
  };
  const layout = { 2: 'awal\\n[[HALAMAN BARU]]\\nlanjut' };

  assert.equal(writeJsonPreference('pageLayout', layout), true);
  assert.deepEqual(readJsonPreference('pageLayout'), layout);
});

test('reader swipe gestures recognize horizontal navigation and reject accidental swipes', () => {
  assert.equal(getSwipeDirection({ dx: -80, dy: 10, duration: 300 }), 'next');
  assert.equal(getSwipeDirection({ dx: 80, dy: 10, duration: 300 }), 'prev');
  assert.equal(getSwipeDirection({ dx: -47, dy: 0, duration: 300 }), null);
  assert.equal(getSwipeDirection({ dx: -80, dy: 70, duration: 300 }), null);
  assert.equal(getSwipeDirection({ dx: -120, dy: 10, duration: 901 }), null);
  assert.equal(getSwipeDirection({ dx: Number.NaN, dy: 0, duration: 100 }), null);
});

test('reader page state calculates group boundaries and scoped progress', () => {
  const pages = [
    { title: 'Tahlil 1' },
    { title: 'Tahlil 2' },
    { quranSurah: 36, title: 'Yasin 1' },
    { quranSurah: 36, title: 'Yasin 2' },
    { quranSurah: 55, title: 'Ar-Rahman' }
  ];

  const bounds = getReadingGroupBounds(pages, 3);
  assert.deepEqual(bounds, { start: 2, end: 3 });
  assert.deepEqual(getPageProgress(3, bounds), { current: 2, total: 2, percent: 100 });
  assert.deepEqual(getReadingGroupBounds([], 0), { start: 0, end: -1 });
  assert.deepEqual(getPageProgress(0, { start: 0, end: -1 }), { current: 0, total: 0, percent: 0 });
});

test('reader appearance applies and persists only supported themes and font sizes', () => {
  const classes = new Set();
  const body = {
    classList: {
      toggle(name, enabled) { if (enabled) classes.add(name); else classes.delete(name); },
      remove(...names) { names.forEach(name => classes.delete(name)); },
      add(name) { classes.add(name); }
    }
  };
  const icon = {}, label = {};
  const attributes = {};
  const button = {
    querySelector(selector) { return selector === '.header-icon' ? icon : label; },
    setAttribute(name, value) { attributes[name] = value; },
    title: ''
  };
  const arabicText = { classList: { toggle(name, enabled) { if (enabled) classes.add(name); else classes.delete(name); } } };
  const control = {};
  const saved = new Map();
  const writePreference = (key, value) => saved.set(key, value);

  assert.equal(applyReaderTheme('dark', { body, button, writePreference }), 'dark');
  assert.equal(classes.has('theme-dark'), true);
  assert.equal(icon.textContent, '☀');
  assert.equal(attributes['aria-label'], 'Aktifkan mode terang');
  assert.equal(saved.get('theme'), 'dark');

  assert.equal(applyReaderTheme('unexpected', { body, button, writePreference }), 'light');
  assert.equal(classes.has('theme-dark'), false);
  assert.equal(icon.textContent, '☾');
  assert.equal(saved.get('theme'), 'light');

  assert.equal(applyReaderFontSize('large', { body, control, arabicText, writePreference }), 'large');
  assert.equal(control.value, 'large');
  assert.equal(classes.has('font-large'), true);
  assert.equal(classes.has('compact'), false);
  assert.equal(saved.get('fontSize'), 'large');

  assert.equal(applyReaderFontSize('small', { body, control, arabicText, writePreference }), 'small');
  assert.equal(classes.has('font-small'), true);
  assert.equal(classes.has('compact'), true);
  assert.equal(applyReaderFontSize('invalid', { body, control, arabicText, writePreference }), 'normal');
  assert.equal(control.value, 'normal');
  assert.equal(classes.has('font-normal'), true);
  assert.equal(classes.has('compact'), false);
  assert.equal(saved.get('fontSize'), 'normal');
});

test('reader section preparation preserves source indexes and authoritative manual dzikir layout', () => {
  const sections = [
    { title: 'Pembukaan' },
    { title: 'Dzikir pertama', collection: 'dzikir' },
    { title: 'Dzikir kedua', collection: 'dzikir' },
    { title: 'Surah Yasin', quranSurah: 36 }
  ];
  const prepared = prepareReadingSections(sections, { 1: 'bagian A\\n[[HALAMAN BARU]]\\nbagian B' });
  assert.deepEqual(prepared.map(section => section.originalIndex), [0, 1, 3]);
  assert.equal(prepared[1].pageLayoutText, 'bagian A\\n[[HALAMAN BARU]]\\nbagian B');
  assert.equal(prepared[1].title, 'Dzikir pertama');
  assert.equal(sections.length, 4);
  assert.equal(sections[1].pageLayoutText, undefined);
});

test('reader section starts fill grouped entries without changing known page indexes', () => {
  assert.deepEqual(completeSectionStarts([0, 2, undefined, 5, undefined], 5), [0, 2, 2, 5, 5]);
  assert.deepEqual(completeSectionStarts([], 3), [0, 0, 0]);
});

test('reader contents expose distinct collection groups with the correct section matching', () => {
  const groups = getReaderContentsGroups();
  assert.deepEqual(groups.map(group => group.title), ['Tahlil', 'Surah Yasin', 'Surah Ar-Rahman', 'Dzikir']);
  assert.equal(groups[0].matches({ title: 'Doa pembuka' }), true);
  assert.equal(groups[0].matches({ collection: 'dzikir' }), false);
  assert.equal(groups[1].matches({ quranSurah: 36 }), true);
  assert.equal(groups[2].matches({ quranSurah: 55 }), true);
  assert.equal(groups[3].matches({ collection: 'dzikir' }), true);
});

test('reader controller navigates inside groups, updates progress, and persists the active page', () => {
  const previousDocument = globalThis.document;
  const previousWindow = globalThis.window;
  const classes = new Set();
  const makeNode = () => ({
    textContent: '', disabled: false, title: '', style: {},
    classList: {
      add(name) { classes.add(name); },
      remove(...names) { names.forEach(name => classes.delete(name)); },
      toggle(name, enabled) { if (enabled) classes.add(name); else classes.delete(name); }
    }
  });
  const nodes = new Map(['pageTitle','arabicText','pageNumber','paper','prevBtn','nextBtn','progressText','progressBar'].map(id => [id, makeNode()]));
  const $ = id => nodes.get(id);
  const pages = [
    { title: 'Tahlil 1', text: 'نص ١' },
    { title: 'Tahlil 2', text: 'نص ٢' },
    { title: 'Yasin 1', text: 'نص ٣', quranSurah: 36 },
    { title: 'Yasin 2', text: 'نص ٤', quranSurah: 36 }
  ];
  let index = 0;
  const saved = [];
  let renders = 0;
  const changedPages = [];
  globalThis.document = { querySelectorAll: () => [] };
  globalThis.window = { setTimeout(callback) { callback(); return 1; } };

  try {
    const controller = createReaderController({
      getPages: () => pages,
      getIndex: () => index,
      setIndex: value => { index = value; },
      $,
      writePreference: (key, value) => saved.push([key, value]),
      renderContents: () => { renders += 1; },
      getReadingGroup,
      getReadingGroupBounds,
      getPageProgress,
      onPageChange: page => changedPages.push(page.title)
    });

    controller.showPage(0);
    assert.equal($('progressText').textContent, '50%');
    controller.next();
    assert.equal(index, 1);
    assert.equal($('pageTitle').textContent, 'Tahlil 2');
    controller.next();
    assert.equal(index, 1, 'navigation must not cross into the next reading group');
    controller.showPage(2);
    controller.prev();
    assert.equal(index, 2, 'previous must not cross into the previous reading group');
    controller.next();
    assert.equal(index, 3);
    assert.equal($('progressText').textContent, '100%');
    assert.deepEqual(saved.at(-1), ['page', 3]);
    assert.ok(renders >= 4);
    assert.ok(changedPages.includes('Yasin 2'));
  } finally {
    if (previousDocument === undefined) delete globalThis.document; else globalThis.document = previousDocument;
    if (previousWindow === undefined) delete globalThis.window; else globalThis.window = previousWindow;
  }
});

test('manual page layout is persisted only when its target is a dzikir section', async () => {
  const sections = [
    { title: 'Tahlil' },
    { title: 'Dzikir Ba’da Shalat', collection: 'dzikir' }
  ];
  const makeFetch = sectionIndex => async url => ({
    ok: true,
    async json() {
      return url.includes('dzikir-overrides')
        ? { sections: [] }
        : {
            format: 'etahlil-dzikir-page-layout',
            scope: 'dzikir-ba-da-shalat',
            sectionIndex,
            text: 'awal\n[[HALAMAN BARU]]\nlanjutan'
          };
    }
  });
  let saved = null;
  const options = {
    sections,
    loadAdditionalSurahs: async () => {},
    readPageLayout: () => ({}),
    writePageLayout: value => { saved = value; }
  };

  await loadOptionalReaderContent({ ...options, fetchImpl: makeFetch(0) });
  assert.equal(saved, null, 'must not attach a dzikir layout to a Tahlil section');

  await loadOptionalReaderContent({ ...options, fetchImpl: makeFetch(1) });
  assert.equal(saved[1], 'awal\n[[HALAMAN BARU]]\nlanjutan');
});

test('Arabic TTS selects an installed Arabic voice and reads queued text chunks', () => {
  const previousDocument = globalThis.document;
  const voice = { lang: 'ar-SA', name: 'Arabic Voice', voiceURI: 'arabic-voice' };
  const spoken = [];
  const voiceSelect = {
    value: 'arabic-voice',
    hidden: false,
    options: [],
    listeners: {},
    replaceChildren() { this.options = []; },
    append(option) { this.options.push(option); },
    addEventListener(name, callback) { this.listeners[name] = callback; }
  };
  class FakeUtterance {
    constructor(text) { this.text = text; }
  }
  const speechSynthesis = {
    getVoices: () => [voice, { lang: 'en-US', name: 'English', voiceURI: 'english' }],
    cancel() {},
    speak(utterance) {
      spoken.push(utterance);
      utterance.onend();
    }
  };
  const status = { textContent: '' };
  const savedPreferences = new Map([['ttsVoice', 'arabic-voice']]);
  globalThis.document = { createElement: () => ({}) };

  try {
    const controller = createReaderAudioController({
      speechSynthesis,
      SpeechSynthesisUtterance: FakeUtterance,
      voiceSelect,
      statusElement: status,
      readPreference: key => savedPreferences.get(key) || '',
      writePreference: (key, value) => savedPreferences.set(key, value)
    });
    const longText = 'اللَّهُ الرَّحْمَٰنُ الرَّحِيمُ '.repeat(20);
    assert.equal(controller.speak(longText), true);
    assert.ok(spoken.length > 1);
    assert.ok(spoken.every(item => item.voice === voice && item.lang === 'ar-SA'));
    assert.equal(voiceSelect.value, 'arabic-voice');
    voiceSelect.value = '';
    voiceSelect.listeners.change();
    assert.equal(savedPreferences.get('ttsVoice'), '');
    assert.match(status.textContent, /TTS selesai/);
    assert.equal(controller.getAvailableVoices().length, 1);
  } finally {
    if (previousDocument === undefined) delete globalThis.document; else globalThis.document = previousDocument;
  }
});

test('classic reader does not expose audio controls; murattal is isolated in its own collection', () => {
  assert.doesNotMatch(readerPageMarkup, /readerAudioPanel|ttsPlayBtn|qariPlayBtn|qariPauseBtn|qariStopBtn|qariAudio/);
});

test('prayer timezone follows the province, not just longitude', () => {
  assert.equal(getZoneForProvince('Kalimantan Selatan').zone, 'WITA');
  assert.equal(getZoneForProvince('Kalimantan Tengah').zone, 'WIB');
  assert.equal(getZoneForProvince('Maluku').zone, 'WIT');
  assert.equal(getZoneForProvince('Maluku Utara').zone, 'WIT');
  assert.equal(getZoneForProvince('Papua Barat Daya').zone, 'WIT');
  assert.equal(getZoneForProvince('Sulawesi Utara').zone, 'WITA');
  assert.equal(getZoneForProvince('Bali').timezone, 'Asia/Makassar');
  assert.equal(getZoneForProvince('DKI Jakarta').zone, 'WIB');
  assert.equal(getZoneForProvince('Provinsi Tidak Dikenal'), null);
});

test('local kitab copy is used only when newer than the source manuscript', () => {
  const chapters = [{ title: 'Bab 1', arabic: '', translation: 'x' }];
  const saved = at => ({ version: 1, updatedAt: at, chapters });
  const source = at => ({ updatedAt: at });
  assert.equal(shouldUseLocalCopy(saved('2026-11-06T10:00:00Z'), source('2026-11-06T09:00:00Z')), true);
  assert.equal(shouldUseLocalCopy(saved('2026-11-06T10:00:00Z'), source('2026-11-06T10:05:00Z')), false);
  assert.equal(shouldUseLocalCopy(saved('2026-11-06T10:00:00Z'), source('2026-11-06T10:00:00Z')), false);
  assert.equal(shouldUseLocalCopy(saved('2026-11-06T10:00:00Z'), {}), true);
  assert.equal(shouldUseLocalCopy(saved('bukan tanggal'), source('2026-11-06T10:00:00Z')), true);
  assert.equal(shouldUseLocalCopy(null, source('2026-11-06T10:00:00Z')), false);
  assert.equal(shouldUseLocalCopy({ version: 1, updatedAt: '2026-11-06T10:00:00Z', chapters: [] }, source('2026-11-06T09:00:00Z')), false);
  assert.equal(shouldUseLocalCopy({ version: 2, updatedAt: '2026-11-06T10:00:00Z', chapters }, source('2026-11-06T09:00:00Z')), false);
});

test('chunkText splits long manuscripts losslessly at paragraph boundaries', () => {
  assert.deepEqual(chunkText(''), []);
  assert.deepEqual(chunkText('pendek'), ['pendek']);
  const paragraphs = Array.from({ length: 50 }, (_, i) => 'بِسْمِ اللّٰهِ ' + i + ' '.repeat(1) + 'x'.repeat(300));
  const text = paragraphs.join('\n\n');
  const chunks = chunkText(text, 1000);
  assert.ok(chunks.length > 5);
  assert.equal(chunks.join(''), text);
  assert.ok(chunks.slice(0, -1).every(chunk => /\n\n$/.test(chunk)), 'potongan berakhir pada batas paragraf');
  // Satu paragraf raksasa tanpa baris kosong dipecah pada akhir baris, tetap tanpa kehilangan teks.
  const lines = Array.from({ length: 400 }, (_, i) => 'baris ' + i + ' ' + 'y'.repeat(60)).join('\n');
  const lineChunks = chunkText(lines, 1000);
  assert.ok(lineChunks.length > 10);
  assert.equal(lineChunks.join(''), lines);
});

test('every bundled manuscript chunks back to the exact original text', () => {
  for (const file of readdirSync('data').filter(name => name.endsWith('.json'))) {
    const document = JSON.parse(readFileSync('data/' + file, 'utf8').replace(/^\uFEFF/, ''));
    for (const chapter of document.chapters) {
      for (const field of ['arabic', 'translation']) {
        const value = chapter[field] || '';
        assert.equal(chunkText(value).join(''), value, file + ' ' + chapter.id + ' ' + field);
      }
    }
  }
});

test('chapter render queue keeps Arabic, Latin, translation order and batches by size', () => {
  const queue = buildChapterQueue({ arabic: 'a'.repeat(9000), latin: 'l', translation: 't'.repeat(5000) });
  const kinds = queue.map(item => item.kind);
  assert.deepEqual(kinds, [...kinds].sort((x, y) => ['arabic', 'latin', 'translation'].indexOf(x) - ['arabic', 'latin', 'translation'].indexOf(y)));
  assert.equal(queue.filter(item => item.first).length, 3);
  assert.equal(queue.filter(item => item.last).length, 3);
  assert.equal(planBatch([]), 0);
  assert.equal(planBatch([{ chunk: 'x'.repeat(20000) }, { chunk: 'y' }]), 1);
  assert.equal(planBatch([{ chunk: 'x'.repeat(4000) }, { chunk: 'y'.repeat(4000) }, { chunk: 'z'.repeat(4000) }]), 2);
});

test('prayer schedule refresh retries after a date change without hammering the network', () => {
  const base = { tickDateKey: '2026-11-08', activeDateKey: '2026-11-07', refreshing: false, lastAttemptAt: Number.NaN, now: 1_000_000 };
  assert.equal(shouldRetryRefresh({ ...base }), true, 'percobaan pertama langsung berjalan');
  assert.equal(shouldRetryRefresh({ ...base, lastAttemptAt: 1_000_000 - 1000 }), false, 'jangan ulang tiap detik');
  assert.equal(shouldRetryRefresh({ ...base, lastAttemptAt: 1_000_000 - 30000 }), true, 'ulang setelah jeda');
  assert.equal(shouldRetryRefresh({ ...base, refreshing: true }), false, 'tidak tumpang tindih');
  assert.equal(shouldRetryRefresh({ ...base, tickDateKey: '2026-11-07' }), false, 'tanggal sama tidak perlu muat ulang');
});

test('paragraphs pair up only when numbering verifies the alignment, without touching the text', () => {
  const numbered = { arabic: 'a1 \n\na2\n\n\na3', translation: '1. t1\n\n2. t2\n\n3. t3', latin: '' };
  assert.deepEqual(pairParagraphs(numbered), [
    { arabic: 'a1 ', translation: '1. t1', heading: false },
    { arabic: 'a2', translation: '2. t2', heading: false },
    { arabic: 'a3', translation: '3. t3', heading: false }
  ]);
  const headed = { arabic: 'basmalah\n\na1\n\na2', translation: 'Shad Ayat 1-2\n\n1. t1\n\n2. t2', latin: '' };
  assert.deepEqual(pairParagraphs(headed).map(pair => pair.heading), [true, false, false], 'judul tanpa nomor bukan terjemah basmalah');
  assert.equal(pairParagraphs({ arabic: 'a1\n\na2\n\na3', translation: 't1\n\nt2\n\nt3', latin: '' }), null, 'jumlah sama tanpa penomoran tidak diverifikasi');
  assert.equal(pairParagraphs({ ...numbered, translation: '1. t1\n\n3. t3\n\n2. t2' }), null, 'nomor tidak berurutan');
  assert.equal(pairParagraphs({ ...numbered, translation: '1. t1\n\n2. t2' }), null, 'jumlah berbeda');
  assert.equal(pairParagraphs({ arabic: 'a', translation: '1. t', latin: '' }), null, 'satu paragraf tidak perlu dilipat');
  assert.equal(pairParagraphs({ ...numbered, latin: 'ada latin' }), null, 'bab dengan Latin tidak dipasangkan');
});

test('chapter view resolves to fold when verified-pairable and honours saved preferences', () => {
  const pairable = { arabic: 'a\n\nb', translation: '1. x\n\n2. y', latin: '' };
  const unverified = { arabic: 'a\n\nb', translation: 'x\n\ny', latin: '' };
  assert.deepEqual(resolveView(pairable, {}), { options: ['fold', 'classic'], view: 'fold' });
  assert.equal(resolveView(pairable, { paired: 'classic' }).view, 'classic');
  assert.equal(resolveView(pairable, { paired: 'tidak-dikenal' }).view, 'fold');
  assert.deepEqual(resolveView(unverified, {}), { options: ['both', 'arabic', 'translation'], view: 'both' }, 'tanpa penomoran tidak dilipat');
  assert.equal(resolveView(unverified, { unpaired: 'arabic' }).view, 'arabic');
  assert.equal(resolveView(unverified, { unpaired: 'fold' }).view, 'both', 'pilihan lipat tidak berlaku bila tidak berpasangan');
  assert.deepEqual(resolveView({ arabic: 'a', translation: '', latin: '' }, {}), { options: [], view: 'both' });
});

test('fold queue yields one item per pair and the other views filter fields', () => {
  const chapter = { arabic: 'a\n\nb\n\nc', translation: '1. x\n\n2. y\n\n3. z', latin: '' };
  const fold = buildChapterQueue(chapter, 'fold');
  assert.deepEqual(fold.map(item => item.kind), ['pair', 'pair', 'pair']);
  assert.deepEqual(fold.map(item => item.translation), ['1. x', '2. y', '3. z']);
  assert.equal(fold.filter(item => item.first).length, 1);
  assert.equal(fold.filter(item => item.last).length, 1);
  assert.deepEqual(buildChapterQueue(chapter, 'arabic').map(item => item.kind), ['arabic']);
  assert.deepEqual(buildChapterQueue(chapter, 'translation').map(item => item.kind), ['translation']);
  assert.deepEqual(buildChapterQueue(chapter, 'both').map(item => item.kind), ['arabic', 'translation']);
  // Bab yang tidak dapat diverifikasi jatuh kembali ke antrean biasa meski diminta 'fold'.
  assert.deepEqual(buildChapterQueue({ arabic: 'a\n\nb', translation: 'x\n\ny', latin: '' }, 'fold').map(item => item.kind), ['arabic', 'translation']);
  assert.equal(planBatch(fold), 3, 'pasangan kecil dirender sekaligus');
  assert.equal(planBatch([{ kind: 'pair', size: 9000 }, { kind: 'pair', size: 10 }]), 1, 'ukuran pasangan memakai field size');
});

test('Jalalain: only verified chapters pair, the heading is not paired with the basmalah, and braces agree with parentheses', () => {
  const document = JSON.parse(readFileSync('data/jalalain.json', 'utf8').replace(/^\uFEFF/, ''));
  let chapters = 0, compared = 0, agreeing = 0;
  for (const chapter of document.chapters) {
    const pairs = pairParagraphs({ arabic: chapter.arabic, translation: chapter.translation, latin: '' });
    if (!pairs) continue;
    chapters += 1;
    assert.equal(pairs[0].heading, true, 'jalalain ' + chapter.id + ': paragraf pertama adalah judul');
    assert.match(pairs[0].translation, /Ayat\s+\d/, 'judul memuat "Ayat"');
    assert.match(pairs[0].arabic, /^\s*بِسْمِ/, 'paragraf Arab pertama adalah basmalah');
    assert.equal(pairs.slice(1).some(pair => pair.heading), false);
    assert.equal(pairs.map(pair => pair.arabic).join('|'), splitParagraphs(chapter.arabic).join('|'), 'teks Arab tetap utuh');
    for (const pair of pairs.slice(1)) {
      const braces = (pair.arabic.match(/\{[^}]*\}/g) || []).length;
      const parentheses = (pair.translation.match(/\([^)]*\)/g) || []).length;
      if (braces || parentheses) { compared += 1; if (braces === parentheses) agreeing += 1; }
    }
  }
  assert.ok(chapters >= 70, 'sebagian besar bab Jalalain terverifikasi (' + chapters + ')');
  assert.ok(agreeing / compared > 0.95, 'blok {..} Arab dan (..) terjemah harus selaras (' + agreeing + '/' + compared + ')');
});
